export class Todo {
  _id: string;
  todo: string;
  isDone: boolean;
  hasAttachment: boolean;
}